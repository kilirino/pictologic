# version
v7 136 minimum

# How to use
1. Go into schematics
2. Click PicToLogic
3. Select an image
4. Adjust settings if you want
5. Export and use the schematic
